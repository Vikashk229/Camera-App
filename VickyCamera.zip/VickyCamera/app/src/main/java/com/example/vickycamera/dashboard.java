package com.example.vickycamera;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class dashboard extends AppCompatActivity {

    private static int CAMERA_PERMISSION_CODE = 922;
    private static int VIDEO_RECORD_CODE = 229;

    private Uri videoStorage;

    private ImageView myImage;
    private Button button2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        myImage = (ImageView)findViewById(R.id.myImage);
        button2 = (Button)findViewById(R.id.button2);

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                camera();
            }
        });

        if (iscameraPresence()) {
            Log.i("VIDEO_RECORD_TAG","There is a Camera..!");
            getCameraPermission();
        }
        else {
            Log.i("VIDEO_RECORD_TAG","There is No Camera..!");
        }
    }

    private void camera() {
        Intent i = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(i, 0);
    }


    public void recordVideoButtonPressed(View view) {
        recordVideo();

    }

    private boolean iscameraPresence() {
        if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)) {
            return true;
        }
        else
            return false;
    }

    private void getCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CAMERA}, CAMERA_PERMISSION_CODE);
        }
    }

    private void recordVideo() {
        Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        startActivityForResult(intent, VIDEO_RECORD_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK){
            Bitmap b = (Bitmap)data.getExtras().get("data");
            myImage.setImageBitmap(b);
        }

        if (requestCode == VIDEO_RECORD_CODE){

            if (resultCode == RESULT_OK) {

                videoStorage = data.getData();
                Log.i("VIDEO_RECORD_TAG", "Video is recorded and available in Storage" + videoStorage);
            }
            else if (requestCode == RESULT_CANCELED) {
                Log.i("VIDEO_RECORD_TAG", "Recorded Video is Cancelled..!");
            }
            else {
                Log.i("VIDEO_RECORD_TAG", "Video is having some error");
            }
        }
    }
}